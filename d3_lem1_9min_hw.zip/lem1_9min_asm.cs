using System;
using System.IO;

namespace lbf_cvtr
{
	/// <summary>
	/// read a location: value;  xxxxx  file
	/// where location is 2-digit hex & value is 4-digt hex
	/// </summary>
	class Class1
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			FileInfo lbf = new FileInfo(@"C:\br\digilent_projs\d3_lem1_9min_hw\hello_world_041120.lbf");
			FileInfo cvf = new FileInfo(@"C:\br\digilent_projs\d3_lem1_9min_hw\hello_world_041120.cvf");
			StreamReader stmr = lbf.OpenText();
			StreamWriter stmw = cvf.CreateText();
			string lbff = stmr.ReadToEnd();
			char[] seps = {':',';'};
			string[] lbffs = lbff.Split(seps);
			int nwds = lbffs.Length/3;
			int nlines = (nwds+31)/32;
			int nplines = (nwds+255)/256;
			byte[] wds = new byte[nlines*32];
			byte[] pbits = new byte[nplines*256];
			for (int i=0; i<nwds; i++)
			{	char[] num = lbffs[3*i+1].ToCharArray();
				int val = 0;
				for (int j=0; j<num.Length; j++)
				{	switch (num[j]) 
					{	case '0': val = val <<4; break;
						case '1': val = val <<4 | 1; break;
						case '2': val = val <<4 | 2; break;
						case '3': val = val <<4 | 3; break;
						case '4': val = val <<4 | 4; break;
						case '5': val = val <<4 | 5; break;
						case '6': val = val <<4 | 6; break;
						case '7': val = val <<4 | 7; break;
						case '8': val = val <<4 | 8; break;
						case '9': val = val <<4 | 9; break;
						case 'A': val = val <<4 | 10; break;
						case 'B': val = val <<4 | 11; break;
						case 'C': val = val <<4 | 12; break;
						case 'D': val = val <<4 | 13; break;
						case 'E': val = val <<4 | 14; break;
						case 'F': val = val <<4 | 15; break;
						default: break;
					}
				}
				wds[i] = (byte)(val >> 7 & 0xff);
				pbits[i] = (byte)(val >> 15 & 1);
			}
			for (int i=0; i<nlines; i++)
			{	stmw.Write("	INIT_{0:X2}  => X\"",i);
				for (int j=31; j>=0; j--) stmw.Write("{0:X2}",wds[i*32+j]);
				stmw.WriteLine("\",");
			}	
			for (int i=0; i<nplines; i++)
			{	stmw.Write("	INITP_{0:X2} => X\"",i);
				for (int j=63; j>=0; j--) stmw.Write("{0:X1}",
												pbits[i*256+j*4+3]*8 + pbits[i*256+j*4+2]*4 +
												pbits[i*256+j*4+1]*2 + pbits[i*256+j*4]);
				stmw.WriteLine("\",");
			}
			stmr.Close();
			stmw.Close();
		}
	}
}
